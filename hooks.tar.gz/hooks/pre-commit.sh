#!/bin/sh

# curl "https://raw.githubusercontent.com/andreafabrizi/Dropbox-Uploader/master/dropbox_uploader.sh" -o dropbox_uploader.sh
chmod +x ./dropbox_uploader.sh
chmod +x ./texlive_install.sh

exit 0
